package com.livestream.app.models;

public class MatchItem {
    private String homeTeam, awayTeam, score, time, league, streamUrl;

    public MatchItem(String homeTeam, String awayTeam, String score, String time, String league, String streamUrl) {
        this.homeTeam = homeTeam; this.awayTeam = awayTeam; this.score = score;
        this.time = time; this.league = league; this.streamUrl = streamUrl;
    }
    public String getHomeTeam()  { return homeTeam; }
    public String getAwayTeam()  { return awayTeam; }
    public String getScore()     { return score; }
    public String getTime()      { return time; }
    public String getLeague()    { return league; }
    public String getStreamUrl() { return streamUrl; }
}
