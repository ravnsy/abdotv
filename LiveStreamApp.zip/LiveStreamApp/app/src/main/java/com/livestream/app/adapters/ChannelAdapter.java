package com.livestream.app.adapters;

import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.livestream.app.R;
import com.livestream.app.models.ChannelItem;
import java.util.List;

public class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.ViewHolder> {

    public interface OnChannelClickListener { void onChannelClick(ChannelItem channel); }

    private List<ChannelItem> channels;
    private OnChannelClickListener listener;

    public ChannelAdapter(List<ChannelItem> channels, OnChannelClickListener listener) {
        this.channels = channels; this.listener = listener;
    }

    public void updateList(List<ChannelItem> newList) {
        this.channels = newList;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_channel, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChannelItem channel = channels.get(position);
        holder.tvName.setText(channel.getName());
        holder.tvCategory.setText(channel.getCategory());
        holder.tvLiveBadge.setVisibility(channel.isLive() ? View.VISIBLE : View.GONE);
        holder.itemView.setOnClickListener(v -> listener.onChannelClick(channel));
    }

    @Override public int getItemCount() { return channels.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCategory, tvLiveBadge;
        ViewHolder(View view) {
            super(view);
            tvName      = view.findViewById(R.id.tv_channel_name);
            tvCategory  = view.findViewById(R.id.tv_category);
            tvLiveBadge = view.findViewById(R.id.tv_live_badge);
        }
    }
}
