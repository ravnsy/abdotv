package com.livestream.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.EditText;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.livestream.app.R;
import com.livestream.app.activities.PlayerActivity;
import com.livestream.app.adapters.ChannelAdapter;
import com.livestream.app.models.ChannelItem;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ChannelsFragment extends Fragment {

    private List<ChannelItem> allChannels = new ArrayList<>();
    private ChannelAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_channels, container, false);

        EditText etSearch = view.findViewById(R.id.et_search);
        RecyclerView recyclerView = view.findViewById(R.id.rv_channels);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        allChannels = getAllChannels();
        adapter = new ChannelAdapter(allChannels, channel -> {
            Intent intent = new Intent(getActivity(), PlayerActivity.class);
            intent.putExtra(PlayerActivity.EXTRA_STREAM_URL, channel.getStreamUrl());
            intent.putExtra(PlayerActivity.EXTRA_STREAM_NAME, channel.getName());
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterChannels(s.toString());
            }
        });

        return view;
    }

    private void filterChannels(String query) {
        List<ChannelItem> filtered = allChannels.stream()
            .filter(c -> c.getName().toLowerCase().contains(query.toLowerCase()))
            .collect(Collectors.toList());
        adapter.updateList(filtered);
    }

    private List<ChannelItem> getAllChannels() {
        List<ChannelItem> list = new ArrayList<>();
        list.add(new ChannelItem("1", "beIN Sports 1", "رياضية", "https://example.com/bein1.m3u8", true));
        list.add(new ChannelItem("2", "beIN Sports 2", "رياضية", "https://example.com/bein2.m3u8", true));
        list.add(new ChannelItem("3", "beIN Sports 3", "رياضية", "https://example.com/bein3.m3u8", false));
        list.add(new ChannelItem("4", "SSC Sport 1", "رياضية", "https://example.com/ssc1.m3u8", true));
        list.add(new ChannelItem("5", "SSC Sport 2", "رياضية", "https://example.com/ssc2.m3u8", true));
        list.add(new ChannelItem("6", "MBC Sport", "رياضية", "https://example.com/mbcsport.m3u8", true));
        list.add(new ChannelItem("7", "Abu Dhabi Sport", "رياضية", "https://example.com/adisport.m3u8", false));
        list.add(new ChannelItem("8", "Al Kass Sport", "رياضية", "https://example.com/alkass.m3u8", true));
        return list;
    }
}
