package com.livestream.app.fragments;

import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import com.livestream.app.R;

public class ProfileFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        TextView tvVersion     = view.findViewById(R.id.tv_version);
        Switch swNotifications = view.findViewById(R.id.sw_notifications);
        Switch swAutoplay      = view.findViewById(R.id.sw_autoplay);
        Button btnClearCache   = view.findViewById(R.id.btn_clear_cache);
        Button btnTelegram     = view.findViewById(R.id.btn_telegram);

        tvVersion.setText("الإصدار: 2.1.0");

        swNotifications.setOnCheckedChangeListener((btn, checked) ->
            Toast.makeText(getContext(), checked ? "الإشعارات مفعّلة" : "الإشعارات مُعطّلة", Toast.LENGTH_SHORT).show());

        swAutoplay.setOnCheckedChangeListener((btn, checked) ->
            Toast.makeText(getContext(), checked ? "التشغيل التلقائي مفعّل" : "التشغيل التلقائي مُعطّل", Toast.LENGTH_SHORT).show());

        btnClearCache.setOnClickListener(v ->
            Toast.makeText(getContext(), "تم مسح الكاش بنجاح ✓", Toast.LENGTH_SHORT).show());

        btnTelegram.setOnClickListener(v ->
            Toast.makeText(getContext(), "جارٍ فتح التيليغرام...", Toast.LENGTH_SHORT).show());

        return view;
    }
}
