package com.livestream.app.models;

public class StreamItem {
    private String id, title, subtitle, badge, streamUrl, icon;

    public StreamItem(String id, String title, String subtitle, String badge, String streamUrl, String icon) {
        this.id = id; this.title = title; this.subtitle = subtitle;
        this.badge = badge; this.streamUrl = streamUrl; this.icon = icon;
    }
    public String getId()        { return id; }
    public String getTitle()     { return title; }
    public String getSubtitle()  { return subtitle; }
    public String getBadge()     { return badge; }
    public String getStreamUrl() { return streamUrl; }
    public String getIcon()      { return icon; }
}
