package com.livestream.app.adapters;

import android.graphics.Color;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.livestream.app.R;
import com.livestream.app.models.MatchItem;
import java.util.List;

public class MatchAdapter extends RecyclerView.Adapter<MatchAdapter.ViewHolder> {

    public interface OnMatchClickListener { void onMatchClick(MatchItem match); }

    private List<MatchItem> matches;
    private OnMatchClickListener listener;

    public MatchAdapter(List<MatchItem> matches, OnMatchClickListener listener) {
        this.matches = matches; this.listener = listener;
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_match, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MatchItem match = matches.get(position);
        holder.tvHomeTeam.setText(match.getHomeTeam());
        holder.tvAwayTeam.setText(match.getAwayTeam());
        holder.tvScore.setText(match.getScore());
        holder.tvTime.setText(match.getTime());
        holder.tvLeague.setText(match.getLeague());

        if (match.getTime().contains("LIVE")) {
            holder.tvTime.setTextColor(Color.RED);
        } else {
            holder.tvTime.setTextColor(Color.GRAY);
        }

        if (!match.getStreamUrl().isEmpty()) {
            holder.itemView.setOnClickListener(v -> listener.onMatchClick(match));
        }
    }

    @Override public int getItemCount() { return matches.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvHomeTeam, tvAwayTeam, tvScore, tvTime, tvLeague;
        ViewHolder(View view) {
            super(view);
            tvHomeTeam = view.findViewById(R.id.tv_home_team);
            tvAwayTeam = view.findViewById(R.id.tv_away_team);
            tvScore    = view.findViewById(R.id.tv_score);
            tvTime     = view.findViewById(R.id.tv_time);
            tvLeague   = view.findViewById(R.id.tv_league);
        }
    }
}
