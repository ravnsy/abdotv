package com.livestream.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.livestream.app.R;
import com.livestream.app.activities.PlayerActivity;
import com.livestream.app.adapters.StreamAdapter;
import com.livestream.app.models.StreamItem;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        RecyclerView rvLive     = view.findViewById(R.id.rv_live_now);
        RecyclerView rvMatches  = view.findViewById(R.id.rv_upcoming_matches);
        RecyclerView rvChannels = view.findViewById(R.id.rv_featured_channels);

        rvLive.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        rvMatches.setLayoutManager(new LinearLayoutManager(getContext()));
        rvChannels.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));

        List<StreamItem> liveItems = getLiveStreams();
        StreamAdapter liveAdapter = new StreamAdapter(liveItems, item -> openPlayer(item));
        rvLive.setAdapter(liveAdapter);

        List<StreamItem> matchItems = getUpcomingMatches();
        StreamAdapter matchAdapter = new StreamAdapter(matchItems, item -> openPlayer(item));
        rvMatches.setAdapter(matchAdapter);

        List<StreamItem> channelItems = getFeaturedChannels();
        StreamAdapter channelAdapter = new StreamAdapter(channelItems, item -> openPlayer(item));
        rvChannels.setAdapter(channelAdapter);

        return view;
    }

    private void openPlayer(StreamItem item) {
        Intent intent = new Intent(getActivity(), PlayerActivity.class);
        intent.putExtra(PlayerActivity.EXTRA_STREAM_URL, item.getStreamUrl());
        intent.putExtra(PlayerActivity.EXTRA_STREAM_NAME, item.getTitle());
        startActivity(intent);
    }

    private List<StreamItem> getLiveStreams() {
        List<StreamItem> list = new ArrayList<>();
        list.add(new StreamItem("1", "دوري أبطال أوروبا", "ريال مدريد vs برشلونة", "LIVE", "https://example.com/stream1.m3u8", "⚽"));
        list.add(new StreamItem("2", "الدوري الإنجليزي", "مانشستر سيتي vs ليفربول", "LIVE", "https://example.com/stream2.m3u8", "⚽"));
        list.add(new StreamItem("3", "الدوري السعودي", "الهلال vs النصر", "LIVE", "https://example.com/stream3.m3u8", "⚽"));
        return list;
    }

    private List<StreamItem> getUpcomingMatches() {
        List<StreamItem> list = new ArrayList<>();
        list.add(new StreamItem("4", "الدوري الإيطالي", "يوفنتوس vs ميلان", "21:00", "https://example.com/stream4.m3u8", "⚽"));
        list.add(new StreamItem("5", "الدوري الإسباني", "أتلتيكو vs إشبيلية", "22:00", "https://example.com/stream5.m3u8", "⚽"));
        return list;
    }

    private List<StreamItem> getFeaturedChannels() {
        List<StreamItem> list = new ArrayList<>();
        list.add(new StreamItem("6", "beIN Sports 1", "قناة رياضية", "HD", "https://example.com/bein1.m3u8", "📺"));
        list.add(new StreamItem("7", "beIN Sports 2", "قناة رياضية", "HD", "https://example.com/bein2.m3u8", "📺"));
        list.add(new StreamItem("8", "SSC Sport 1", "قناة رياضية", "HD", "https://example.com/ssc1.m3u8", "📺"));
        list.add(new StreamItem("9", "MBC Sport", "قناة رياضية", "HD", "https://example.com/mbc.m3u8", "📺"));
        return list;
    }
}
