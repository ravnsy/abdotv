package com.livestream.app.activities;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.StyledPlayerView;
import com.livestream.app.R;

public class PlayerActivity extends AppCompatActivity {

    public static final String EXTRA_STREAM_URL  = "stream_url";
    public static final String EXTRA_STREAM_NAME = "stream_name";

    private ExoPlayer player;
    private StyledPlayerView playerView;
    private ProgressBar progressBar;
    private TextView tvChannelName;
    private ImageButton btnBack, btnFavorite, btnQuality;
    private boolean isFavorite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_player);

        String streamUrl  = getIntent().getStringExtra(EXTRA_STREAM_URL);
        String streamName = getIntent().getStringExtra(EXTRA_STREAM_NAME);

        playerView    = findViewById(R.id.player_view);
        progressBar   = findViewById(R.id.progress_bar);
        tvChannelName = findViewById(R.id.tv_channel_name);
        btnBack       = findViewById(R.id.btn_back);
        btnFavorite   = findViewById(R.id.btn_favorite);
        btnQuality    = findViewById(R.id.btn_quality);

        tvChannelName.setText(streamName != null ? streamName : "بث مباشر");

        btnBack.setOnClickListener(v -> onBackPressed());
        btnFavorite.setOnClickListener(v -> toggleFavorite());
        btnQuality.setOnClickListener(v ->
            Toast.makeText(this, "اختيار الجودة قريباً", Toast.LENGTH_SHORT).show());

        initPlayer(streamUrl);
    }

    private void initPlayer(String url) {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        if (url != null && !url.isEmpty()) {
            MediaItem mediaItem = MediaItem.fromUri(Uri.parse(url));
            player.setMediaItem(mediaItem);
            player.prepare();
            player.play();
        }

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) {
                    progressBar.setVisibility(View.VISIBLE);
                } else {
                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPlayerError(@NonNull PlaybackException error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(PlayerActivity.this,
                    "خطأ في تشغيل البث: " + error.getMessage(),
                    Toast.LENGTH_LONG).show();
            }
        });
    }

    private void toggleFavorite() {
        isFavorite = !isFavorite;
        btnFavorite.setImageResource(isFavorite ?
            R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
        Toast.makeText(this, isFavorite ? "تمت الإضافة للمفضلة" : "تمت الإزالة من المفضلة",
            Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause()  { super.onPause();  if (player != null) player.pause(); }

    @Override
    protected void onResume() { super.onResume(); if (player != null) player.play();  }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) { player.release(); player = null; }
    }
}
