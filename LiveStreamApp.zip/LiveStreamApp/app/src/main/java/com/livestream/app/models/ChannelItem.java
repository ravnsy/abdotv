package com.livestream.app.models;

public class ChannelItem {
    private String id, name, category, streamUrl;
    private boolean isLive;

    public ChannelItem(String id, String name, String category, String streamUrl, boolean isLive) {
        this.id = id; this.name = name; this.category = category;
        this.streamUrl = streamUrl; this.isLive = isLive;
    }
    public String getId()        { return id; }
    public String getName()      { return name; }
    public String getCategory()  { return category; }
    public String getStreamUrl() { return streamUrl; }
    public boolean isLive()      { return isLive; }
}
