package com.livestream.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.TabLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.livestream.app.R;
import com.livestream.app.activities.PlayerActivity;
import com.livestream.app.adapters.MatchAdapter;
import com.livestream.app.models.MatchItem;
import java.util.ArrayList;
import java.util.List;

public class MatchesFragment extends Fragment {

    private RecyclerView recyclerView;
    private MatchAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_matches, container, false);

        TabLayout tabLayout = view.findViewById(R.id.tab_layout);
        recyclerView = view.findViewById(R.id.rv_matches);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        loadMatches("live");

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0: loadMatches("live"); break;
                    case 1: loadMatches("upcoming"); break;
                    case 2: loadMatches("finished"); break;
                }
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        return view;
    }

    private void loadMatches(String type) {
        List<MatchItem> matches = new ArrayList<>();
        if (type.equals("live")) {
            matches.add(new MatchItem("ريال مدريد", "برشلونة", "2 - 1", "LIVE 67'", "دوري أبطال أوروبا", "https://example.com/s1.m3u8"));
            matches.add(new MatchItem("مانشستر سيتي", "ليفربول", "0 - 0", "LIVE 34'", "الدوري الإنجليزي", "https://example.com/s2.m3u8"));
            matches.add(new MatchItem("الهلال", "النصر", "1 - 0", "LIVE 80'", "الدوري السعودي", "https://example.com/s3.m3u8"));
        } else if (type.equals("upcoming")) {
            matches.add(new MatchItem("يوفنتوس", "ميلان", "vs", "21:00", "الدوري الإيطالي", ""));
            matches.add(new MatchItem("أتلتيكو", "إشبيلية", "vs", "22:00", "الدوري الإسباني", ""));
            matches.add(new MatchItem("بايرن", "دورتموند", "vs", "20:30", "الدوري الألماني", ""));
        } else {
            matches.add(new MatchItem("PSG", "مارسيليا", "3 - 1", "انتهت", "الدوري الفرنسي", ""));
            matches.add(new MatchItem("أرسنال", "تشيلسي", "2 - 2", "انتهت", "الدوري الإنجليزي", ""));
        }

        adapter = new MatchAdapter(matches, match -> {
            if (!match.getStreamUrl().isEmpty()) {
                Intent intent = new Intent(getActivity(), PlayerActivity.class);
                intent.putExtra(PlayerActivity.EXTRA_STREAM_URL, match.getStreamUrl());
                intent.putExtra(PlayerActivity.EXTRA_STREAM_NAME, match.getHomeTeam() + " vs " + match.getAwayTeam());
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(adapter);
    }
}
