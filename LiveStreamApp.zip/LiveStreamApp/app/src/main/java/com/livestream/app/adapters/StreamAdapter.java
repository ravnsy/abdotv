package com.livestream.app.adapters;

import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.livestream.app.R;
import com.livestream.app.models.StreamItem;
import java.util.List;

public class StreamAdapter extends RecyclerView.Adapter<StreamAdapter.ViewHolder> {

    public interface OnItemClickListener { void onItemClick(StreamItem item); }

    private List<StreamItem> items;
    private OnItemClickListener listener;

    public StreamAdapter(List<StreamItem> items, OnItemClickListener listener) {
        this.items = items; this.listener = listener;
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_stream, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        StreamItem item = items.get(position);
        holder.tvTitle.setText(item.getTitle());
        holder.tvSubtitle.setText(item.getSubtitle());
        holder.tvBadge.setText(item.getBadge());
        holder.tvIcon.setText(item.getIcon());
        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override public int getItemCount() { return items.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvSubtitle, tvBadge, tvIcon;
        ViewHolder(View view) {
            super(view);
            tvTitle    = view.findViewById(R.id.tv_title);
            tvSubtitle = view.findViewById(R.id.tv_subtitle);
            tvBadge    = view.findViewById(R.id.tv_badge);
            tvIcon     = view.findViewById(R.id.tv_icon);
        }
    }
}
